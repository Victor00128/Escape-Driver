# 🚗 ESCAPE DRIVER - Police Chase Game

Un emocionante juego de persecución policial estilo GTA con sistema de estrellas, power-ups, logros y física arcade.

![Escape Driver](https://img.shields.io/badge/Game-Arcade-yellow) ![React](https://img.shields.io/badge/React-19-blue) ![TypeScript](https://img.shields.io/badge/TypeScript-5.6-blue)

## 🎮 Características Principales

### 🌟 Sistema GTA de Estrellas
- **1-5 estrellas** de nivel de búsqueda
- Más estrellas = más policías y más agresivos
- Las estrellas aumentan con el tiempo y los policías destruidos

### ⚡ Power-ups
| Power-up | Efecto | Duración |
|----------|--------|----------|
| ⚡ Turbo | Velocidad x1.8 | 6 segundos |
| 🛡️ Escudo | Invencibilidad | 10 segundos |
| 🧲 Imán | Atrae monedas | 12 segundos |
| 💣 Bomba | Destruye 1 policía | Instantáneo |

### 🏆 Sistema de Logros
- 🪙 **Primera Moneda** - Recoge tu primera moneda
- 💰 **Cazador** - Recoge 50 monedas
- 💥 **Primera Sangre** - Destruye un policía
- 🔥 **Destructor** - Destruye 10 policías
- 💨 **Rey del Drift** - Driftea 30 segundos
- 😰 **Por Poco** - 10 near miss seguidos
- ⏱️ **Superviviente** - Sobrevive 2 minutos
- ⭐ **5 Estrellas** - Alcanza nivel máximo
- 🛡️ **Intocable** - Gana sin perder vidas
- 💣 **Reacción en Cadena** - 3 policías explotan a la vez

### 🚔 IA Policial Inteligente
- Los policías **evitan chocar entre sí**
- Algunos **predicen tu movimiento** e intentan cortarte
- Velocidad adaptativa según la distancia
- ¡Puedes hacer que choquen entre sí para destruirlos!

### 🎯 Modos de Dificultad
| Modo | Policías | Tiempo | Max Policías |
|------|----------|--------|--------------|
| ⭐ Normal | 4 | 2 min | 10 |
| ⭐⭐ Difícil | 6 | 3 min | 15 |
| ⭐⭐⭐ Imposible | 8 | 4 min | 25 |

## 🕹️ Controles

| Tecla | Acción |
|-------|--------|
| ↑ / W | Acelerar |
| ↓ / S | Frenar / Reversa |
| ← / A | Girar izquierda |
| → / D | Girar derecha |
| **ESPACIO** | **Drift (derrape)** |
| P | Pausar |

## 🎲 Mecánicas de Juego

- **💰 Monedas**: Recógelas para puntos (+15 × multiplicador)
- **✨ Multiplicador**: Sube hasta x10 con acciones continuas
- **🎯 Near Miss**: Pasa cerca de policías para puntos bonus
- **💥 Colisiones**: Haz que 2 policías choquen = ambos explotan
- **🏆 Victoria**: Sobrevive el tiempo O destruye todos los policías

## 📦 Instalación

### Requisitos
- Node.js 18+ (recomendado 20+)
- npm o pnpm

### Instalación rápida

```bash
# Clonar o descargar
cd police-chase-game

# Instalar dependencias
npm install --legacy-peer-deps

# Iniciar servidor de desarrollo
npm run dev

# Abrir en navegador
# http://localhost:3000
```

## 🏗️ Compilar para Producción

```bash
npm run build
npm start
```

## 🛠️ Tecnologías

- **React 19** - Framework UI
- **TypeScript 5.6** - Tipado estático
- **Vite 5** - Build tool ultra-rápido
- **Tailwind CSS 4** - Estilos utility-first
- **HTML5 Canvas** - Renderizado 2D optimizado
- **Web Audio API** - Sonidos sintetizados

## 📁 Estructura

```
police-chase-game/
├── client/
│   ├── src/
│   │   ├── pages/
│   │   │   ├── Home.tsx      # Menú principal
│   │   │   └── Game.tsx      # Lógica del juego
│   │   ├── App.tsx           # Router
│   │   └── index.css         # Estilos
│   └── index.html
├── server/
│   └── index.ts              # Servidor Express
└── package.json
```

## 🎮 Tips para Jugar

1. **Usa el drift** (ESPACIO) para giros cerrados
2. **Recoge los turbos** (⚡) para escapar rápido
3. **El imán** (🧲) hace más fácil recoger monedas
4. **Conserva las bombas** (💣) para emergencias
5. **Mantén el multiplicador** alto con acciones continuas
6. **¡Haz que los policías choquen entre sí!**

## 📝 Licencia

MIT License - Libre para uso personal y comercial.

---

**Desarrollado con ❤️ usando React, Canvas y mucha adrenalina**
